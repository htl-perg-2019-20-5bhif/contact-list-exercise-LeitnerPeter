﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace ContractList_HUE
{

    public partial class Person
    {        
        [DataMember(Name = "id")]
        public int Id { get; set; }

        [DataMember(Name = "firstName")]
        public string FirstName { get; set; }

        [DataMember(Name = "lastName")]
        public string LastName { get; set; }

        [DataMember(Name = "email")]
        public string Email { get; set; }

    }

    [ApiController]
    public class PersonenController : ControllerBase
    {
        private static readonly List<Person> contacts = 
            new List<Person>{ 
                new Person { Id=1, FirstName="Peter", LastName="Leitner", Email="peterleitner@gmail.com" },
                new Person { Id=2, FirstName="Felix", LastName="Leibetseder", Email="felixleibetseder@gmail.com" },
                new Person { Id=3, FirstName="Thomas", LastName="Bohm", Email="thomasbohm@gmail.com" }
        };

        [HttpGet]
        [Route("/contacts")]
        public IActionResult GetAllPeople()
        {
            return Ok(contacts);
        }

        [HttpPost]
        [Route("/contacts")]
        public IActionResult AddPerson([FromBody]Person person)
        {
            contacts.Add(person);
            return Created("Person erstellt", person);
        }

        [HttpDelete]
        [Route("/contacts/{id}")]
        public IActionResult DeletePerson(int id)
        {
            if (id >= 0 && id < contacts.Count)
            {
                contacts.RemoveAt(id);
                return NoContent();
            }

            return BadRequest("Falsche Id");
        }

        [HttpGet]
        [Route("/contacts/FindByName", Name = "FindByName")]
        public IActionResult FindByName([FromQuery]string nameFilter)
        {
            IEnumerable<Person> people = from person in contacts
                  where person.FirstName == nameFilter || person.LastName == nameFilter
                  select person;

            if (people.Count() > 0)
            {
                return Ok(people);
            }
            return BadRequest("Name existiert nicht");
        }



    }
}
